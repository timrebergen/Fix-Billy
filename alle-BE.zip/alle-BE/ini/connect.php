<?php

$con= pg_connect("host=localhost dbname=postgres user=postgres password=WelKom7993") or die("ERROR:could not connect to the database!!!");
?>